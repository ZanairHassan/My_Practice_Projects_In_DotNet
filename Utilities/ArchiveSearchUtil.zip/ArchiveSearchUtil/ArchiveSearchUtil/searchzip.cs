﻿using System;
using System.IO;
using System.IO.Compression;

namespace ArchiveSearchUtil
{
    internal class searchzip
    {
        private string logFolderPath;

        public void loggings(string folderPath)
        {
            string logFolder = Path.Combine(folderPath, "Logs");
            Directory.CreateDirectory(logFolder);
            logFolderPath = logFolder;
        }

        public void Log(string message)
        {
            string logFilePath = Path.Combine(logFolderPath, $"{DateTime.Now:yyyyMMddHHmmss}.txt");
            using (StreamWriter writer = new StreamWriter(logFilePath, true))
            {
                writer.WriteLine($"{DateTime.Now} - {message}");
            }
        }
        public bool SearchFileInZip(string zipFilePath, string searchFileName)
        {
            try
            {
                if (!File.Exists(zipFilePath))
                {
                    Log("Zip file not found.");
                    return false;
                }

                using (ZipArchive archive = ZipFile.OpenRead(zipFilePath))
                {
                    try
                    {
                        foreach (ZipArchiveEntry entry in archive.Entries)
                        {
                            if (entry.FullName.ToLower().Contains(searchFileName.ToLower()))
                            {
                                var currentTimeFolder = DateTime.Now.ToString("yyyyMMddHmmss");
                                var destinfolder = Path.Combine(logFolderPath, currentTimeFolder);
                                if (!Directory.Exists(destinfolder))
                                {
                                    Directory.CreateDirectory(destinfolder);
                                }
                                var destinfile = Path.Combine(destinfolder, entry.Name);
                                entry.ExtractToFile(destinfile);
                                Log($"Found and extracted {searchFileName} from {zipFilePath} to {destinfile}");
                                Console.WriteLine($"The file is copied at the path: {destinfile}");
                                return true;
                            }
                        }
                    }
                    catch(InvalidDataException ex)
                    {
                        Log($"maybe the file is cruppeted: {ex.Message}");
                    }
                }
            }
            catch(NotSupportedException ex)
            {
                Log($"the file is not supported for the purpose: {ex.Message}");
            }
            catch (UnauthorizedAccessException ex)
            {
                Log($"Unauthorized access: {ex.Message}");
            }
            catch (Exception ex)
            {
                Log($"An error occurred: {ex.Message}");
                return false;
            }

            Log($"File {searchFileName} not found in {zipFilePath}");
            return false;
        }
    }
}

//using System;
//using System.IO;
//using System.IO.Compression;

//namespace ArchiveSearchUtil
//{
//    internal class searchzip
//    {
//        public bool SearchFileInZip(string zipFilePath, string searchFileName)
//        {
//            try
//            {
//                if (!File.Exists(zipFilePath))
//                {
//                    Console.WriteLine("Zip file not found.");
//                    return false;
//                }
//                using (ZipArchive archive = ZipFile.OpenRead(zipFilePath))
//                {
//                    foreach (ZipArchiveEntry entry in archive.Entries)
//                    {
//                        if (entry.FullName.ToLower().Contains(searchFileName.ToLower()))
//                        {
//                            var currentTimeFolder = DateTime.Now.ToString("yyyyMMddHmmss");
//                            var destinFolder= Path.Combine(Environment.CurrentDirectory, currentTimeFolder);
//                            if (!Directory.Exists(destinFolder))
//                            {
//                                Directory.CreateDirectory(destinFolder);
//                            }
//                            var destinFile=Path.Combine(destinFolder, entry.Name);
//                            entry.ExtractToFile(destinFile);
//                            Console.WriteLine($"The file is copied at the path: {destinFile}");
//                            return true;
//                        }
//                    }
//                }
//            }
//            catch (UnauthorizedAccessException ex)
//            {
//                Console.WriteLine($"Unauthorized access: {ex.Message}");
//            }
//            catch (Exception ex)
//            {
//                Console.WriteLine($"An error occurred:maybe the file is cruppted : {ex.Message}");
//                return false;
//            }

//            return false;
//        }
//    }
//}