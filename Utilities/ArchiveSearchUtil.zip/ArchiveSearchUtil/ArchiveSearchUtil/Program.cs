﻿using System;
using System.IO;
using System.IO.Compression;

namespace ArchiveSearchUtil
{
    internal class Program
    {
        static void Main(string[] args)
        {
            zipfilecheck abc = new zipfilecheck();
            Console.WriteLine("Enter the complete folder path: ");
            string folderPath = Console.ReadLine();
            searchzip search = new searchzip();
            search.loggings(folderPath);

            Console.WriteLine("Enter the file name to search within ZIP files: ");
            string searchFileName = Console.ReadLine();

            if (!Directory.Exists(folderPath))
            {
                search.Log("Folder not found.");
                return;
            }

           var files = Directory.GetFiles(folderPath);

            Console.WriteLine("check for different files...");
            foreach (var file in files)
            {
                if (abc.IsZipFile(file))
                {
                    Console.WriteLine("this is a zip file " + file);
                    bool found = search.SearchFileInZip(file, searchFileName);
                }
                else
                {
                    Console.WriteLine("this is not a zip file " + file);
                }
            }
          
            Console.WriteLine("Press any key to continue");
            Console.ReadLine();
        }
    }
}

////Console.WriteLine("Searching files in ZIP archives...");
//foreach (string file in files)
//{
//    Console.WriteLine($"Searching in {Path.GetFileName(file)}...");
//    bool found = search.SearchFileInZip(file, "ab.txt");

//    // Display the result
//    Console.WriteLine($"File found in {Path.GetFileName(file)}: {(found ? "Yes" : "No")}");
//}